@extends('template.main')
@section('konten')
<div class="page-inner">
    <div class="page-header">
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="#">
                    <i class="fa fa-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="fas fa-angle-right"></i>
            </li>
            <li class="nav-item">
                <a href="#">Master Data</a>
            </li>
            <li class="separator">
                <i class="fas fa-angle-right"></i>
            </li>
            <li class="nav-item">
                <a href="{{ route('artikel')}}">Data Artikel</a>
            </li>
            <li class="separator">
                <i class="fas fa-angle-right"></i>
            </li>
            <li class="nav-item">
                <a href="#">Edit Data Artikel</a>
            </li>
        </ul>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">Edit Data : {{ $edit['judul_artikel']}}</div>
                </div>
                <form action="{{ route('artikel.update', $edit['id']) }}" method="post" enctype="multipart/form-data">
                    @method('PUT')
                    @csrf
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12 col-lg-12">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="jd">Judul Artikel</label>
                                            <input type="text" value="{{ $edit['judul_artikel']}}" name="judul" class="form-control" id="jd" placeholder="Masukkan Judul">
                                            
                                            @error('judul')
                                            <small class="text-danger">
                                                {{ $message }}
                                            </small>
                                            @enderror
 
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="password">Upload Gambar</label> <br><br>
                                            
                                            @if ($edit['gambar'])
                                                <img style="width: 10%" class="mb-4" src="{{ asset('upload/'.$edit['gambar'])}}">                    
                                            <input type="file" name="gambar" class="form-control">
                                            <small class="text-danger">
                                                *kosongkan jika tidak ingin mengubah gambar
                                            </small>     

                                            @else
                                            <input type="file" name="gambar" class="form-control">           
                                            @endif
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="form-group">
                                    <label for="comment">Isi</label>
                                    <textarea class="form-control" name="isi" rows="5">{{ $edit['isi']}}</textarea>
                                    @error('isi')
                                    <small class="text-danger">
                                        {{ $message }}
                                    </small>
                                    @enderror
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <center>
                        <button type="submit" class="btn btn-secondary"><i class="icon-refresh"></i> Update</button>
                        </center>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection