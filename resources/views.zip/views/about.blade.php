{{-- manggil file template utk meniru template --}}
@extends('template.app')

{{-- 'section' utk nampilin @yield yg td ada di file app.blade.php --}}
@section('konten')
<p>Ini halaman about</p>
@endsection
