@extends('template.app')

{{-- 'section' utk nampilin @yield yg td ada di file app.blade.php --}}
@section('login')
<p>Ini halaman home</p>
@endsection