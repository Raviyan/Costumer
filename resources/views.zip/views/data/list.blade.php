<h1>Data kategori</h1>

{{-- $id adlh jln/inputan id yg diinput oleh user --}}
{{-- {{ $id }} --}}

<ul>
    {{-- $kategori adlh parameter yg udh didefisinikan di fungsi index pada file controller=(LatihanController) --}}
    {{-- $cek sbg penanda apakah data ditemukan / tidak --}}
    @php
        $cek = false;
    @endphp

    @foreach ($kategori as $item)
        @if ($id == $item['id'])
            <li>{{ $item['id'] }}. {{ $item['nama_kategori'] }}</li>
            {{-- Ubah $cek jd true krn data ditemukan --}}
            @php
                $cek = true;
            @endphp
        @endif
    @endforeach

    {{-- Jika $cek masih false, tampilkan pesan "ID nya tidak ditemukan" --}}
    @if (! $cek)
        <li>ID nya tidak ditemukan</li>
    @endif
</ul>
