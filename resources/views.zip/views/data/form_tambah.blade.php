{{-- jika actionnya spt dibwh ({{route('simpanPost')}}), hrs tentukan/defined route tsb di file web.php --}}
{{-- enctype="multipart/form-data hrs ada jika form kita ada inputan file/dokumennya --}}
<form action="{{route('simpanPost')}}" enctype="multipart/form-data" method="post">
    {{-- @csrf wajib ada ketika kita membuat form, utk security --}}
    @csrf
    <label for="">Nama</label>
    <input type="text" name="nama" id="">
    <button type="submit">kirim</button>
</form>