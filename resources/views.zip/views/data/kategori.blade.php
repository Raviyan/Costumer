<!-- $id dan $ipk adlh parameter yg sdh didefinisikan di fungsi cekID pada file controller=(LatihanController) -->
{{-- {{"OKREK $id $ipk"}} --}}

{{"DAFTAR DATA KATEGORI"}}
<br><br>
<a href="{{route('tambah')}}">Tambah Data</a>